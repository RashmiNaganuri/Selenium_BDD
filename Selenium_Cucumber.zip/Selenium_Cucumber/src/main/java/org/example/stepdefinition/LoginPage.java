package org.example.stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class LoginPage {
    WebDriver driver=new ChromeDriver();

    @Given("browser is open and user is on godaddy homepage")
    public void browser_is_open() {
        System.setProperty("Webdriver.chrome.driver","C:\\Selenium Jars and drivers\\drivers\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe.");
        driver.get("https://www.godaddy.com/en-in");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
    }

    @When("user clicks on Domains")
    public void user_clicks_on_Domains() {

        driver.findElement(By.xpath("//*[@id=\"id-631b049a-e9c0-4d24-8710-c504745206dd\"]/div[2]/div[1]/ul/li[1]")).click();

    }

    @And("user clicks on Domain Name Search")
    public void user_clicks_on_domain_name_search() {

        driver.findElement(By.xpath("//*[@id=\"id-631b049a-e9c0-4d24-8710-c504745206dd\"]/div[2]/div[1]/ul/li[1]/div/div[2]/div[1]/ul[1]/li[2]/div/span/div/span/a")).click();

    }

    @And("get the value of title of Domain Name Search page")
    public void get_the_value_of_title_of_domain_name_search_page() {
        String ExpectedValue= "GoDaddy Domain Search - Buy and Register Available Domain Names";
        String FetchedValue= driver.getTitle();
        if(ExpectedValue.equals(FetchedValue))
        {
            System.out.println("Values match:" + ExpectedValue);
        }
        else{
            System.out.println("Values do not match");
        }
    }

    @And("verify the presence of search box in Domain Name Search page")
    public void verify_searchbox_domainnamepage()
    {
        WebElement SearchBox=driver.findElement(By.xpath("//*[@id=\"id-1467954b-c5e3-4b0c-9046-9fc94d8ca892\"]/section/div/div/section/div/div/div/div/form/div/div/div"));
        if(SearchBox.isDisplayed()) {
            System.out.println("Search Box is present on the screen");

            if (SearchBox.isEnabled()) {
                System.out.println("Search box is enabled");
            } else {
                System.out.println("Search box is disabled");
            }
        }else
        {
            System.out.println("Search box is not present on the screen");
        }
    }
    @And("verify the presence of BuyIt button along with search box")
    public void verify_presence_of_buyit()
    {
        WebElement BuyIt=driver.findElement(By.xpath("//*[@id=\"id-1467954b-c5e3-4b0c-9046-9fc94d8ca892\"]/section/div/div/section/div/div/div/div/form/div/button"));
        if(BuyIt.isDisplayed())
        {
            System.out.println("BuyIt button is present on screen");
        }
        else
        {
            System.out.println("BuyIt button is not present on screen");
        }
    }

    @And("enter some value in domain name search box and click on BuyIt")
    public void enter_domain_value()
    {
        driver.findElement(By.name("searchText")).sendKeys("ba.com");
        driver.findElement(By.xpath("//*[@id=\"id-1467954b-c5e3-4b0c-9046-9fc94d8ca892\"]/section/div/div/section/div/div/div/div/form/div/button")).click();
    }
    @Then("verify if add to cart and price is displayed along with domain name")
    public void verify_addtocart_price()
    {
        WebElement Addtocart=driver.findElement(By.xpath("//*[@id=\"search-app\"]/div/div/div[2]/div[1]/div[2]/div[1]/div[2]/div[5]/div/div/div[2]/button"));
        WebElement Price=driver.findElement(By.xpath("//*[@id=\"search-app\"]/div/div/div[2]/div[1]/div[2]/div[1]/div[2]/div[4]/div[2]/div[2]/div/span"));
        if(Addtocart.isDisplayed())
        {
            System.out.println("Add to Cart button is visible");
            if(Price.isDisplayed())
            {
                System.out.println("Price is displayed");
            }
            else
            {
                System.out.println("Price is not displayed");
            }
        }
        else
        {
            System.out.println("Add to Cart button is not visible");
        }
    }
}

