package org.example.stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class RegistrationPage {

    WebDriver driver=new ChromeDriver();

    @Given("guest user trying to purchase product")
    public  void guestuser_product_purchase() throws InterruptedException {
        System.setProperty("Webdriver.chrome.driver","C:\\Selenium Jars and drivers\\drivers\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe.");
        driver.get("https://jpetstore.aspectran.com/catalog/");
        driver.manage().window().maximize();
        driver.findElement(By.xpath("//*[@id=\"QuickLinks\"]/a[2]")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"Catalog\"]/table/tbody/tr[2]/td[1]/a")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"Catalog\"]/table/tbody/tr[2]/td[1]/a")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"CenterForm\"]/div/a")).click();
        Thread.sleep(5000);
        WebElement purchase= driver.findElement(By.xpath("//*[@id=\"Cart\"]/a"));
        purchase.click();
        if(purchase.equals(true))
        {
            System.out.println("Guest User is able to purchase the product");
        }
        else
        {
            System.out.println("You must sign on before attempting to check out. Please sign on and try checking out again.");
        }
        Thread.sleep(10000);
    }
    @And("guest user trying to register on the website")
    public void guest_user_registration() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"Signon\"]/div/a")).click();
        driver.findElement(By.name("username")).sendKeys("Rashmi444");
        driver.findElement(By.name("password")).sendKeys("rash1990");
        driver.findElement(By.name("repeatedPassword")).sendKeys("rash1990");
        driver.findElement(By.name("firstName")).sendKeys("Rashmi");
        driver.findElement(By.name("lastName")).sendKeys("Naganuri");
        driver.findElement(By.name("email")).sendKeys("abc@gmail.com");
        driver.findElement(By.name("phone")).sendKeys("9036042224");
        driver.findElement(By.name("address1")).sendKeys("United Meadows");
        driver.findElement(By.name("address2")).sendKeys("Brookefield,KUndalhalli");
        driver.findElement(By.name("city")).sendKeys("Bangalore");
        driver.findElement(By.name("state")).sendKeys("Karnataka");
        driver.findElement(By.name("zip")).sendKeys("560038");
        driver.findElement(By.name("country")).sendKeys("India");
        driver.findElement(By.xpath("//*[@id=\"CenterForm\"]/form/div/button")).click();
        System.out.println("User is able to register his account successfully");
        Thread.sleep(10000);

    }
    @And("User views and edits the account information")
    public void View_edit_accountinfo() throws InterruptedException {
        driver.findElement(By.name("username")).clear();
        driver.findElement(By.name("username")).sendKeys("Rashmi444");
        driver.findElement(By.name("password")).clear();
        driver.findElement(By.name("password")).sendKeys("rash1990");
        driver.findElement(By.xpath("//*[@id=\"Signon\"]/form/div/div/button")).click();

        driver.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[3]")).click();
        Thread.sleep(5000);
        driver.findElement(By.name("password")).sendKeys("rash1990");
        driver.findElement(By.name("repeatedPassword")).sendKeys("rash1990");
        driver.findElement(By.name("zip")).clear();
        driver.findElement(By.name("zip")).sendKeys("667111");
        driver.findElement(By.name("country")).clear();
        driver.findElement(By.name("country")).sendKeys("US");
        driver.findElement(By.xpath("//*[@id=\"CenterForm\"]/form/div/button")).click();
        System.out.println("User is able to edit and save the information successfully");
        Thread.sleep(5000);

    }
    @When("registered user views all products on the website")
    public void view_all_products() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"QuickLinks\"]/a[2]")).click();
        Thread.sleep(5000);
        List<WebElement> products=driver.findElements(By.xpath("//a[contains(@href, '/catalog/products')]"));
        for(WebElement prodlist : products)
        {
            String Actualvalue=prodlist.getText();
            System.out.println("User is able to view all the products: " +Actualvalue);
        }
    }
    @Then("User Logs out from the application")
    public void user_logout_application() {
        driver.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[4]")).click();
        System.out.println("User is able to sign out successfully");
        driver.quit();
    }
}
