package org.example.stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

public class ShoppingCart {

    WebDriver driver = new ChromeDriver();

    @Given("User is on e-commerce website")
    public void User_ecommerce_website() {
        System.setProperty("Webdriver.chrome.driver", "C:\\Selenium Jars and drivers\\drivers\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe.");
        driver.get("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2F%3Fref_%3Dnav_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0");

        //driver.findElement(By.xpath("//*[@id=\"sc-buy-box-ptc-button\"]/span/input")).click();
        driver.findElement(By.xpath("//*[@id=\"ap_email\"]")).sendKeys("rashmi.naganuri234@gmail.com");
        driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"ap_password\"]")).sendKeys("Rash8050656505");
        driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
        driver.manage().window().maximize();
        System.out.println("User is able to log in to the website");
    }

    @When("User searches the specific product and validates the price in cart")
    public void User_validates_price() throws InterruptedException {
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys("headset");
        driver.findElement(By.xpath("//*[@id=\"nav-search-submit-button\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[1]/div/span[1]/div[1]/div[4]/div/div/div/div/div/div[2]/div/div/div[1]/h2/a/span")).click();

        Set<String> ids = driver.getWindowHandles();
        Iterator<String> it = ids.iterator();
        String parentId = it.next();
        String childId = it.next();
        driver.switchTo().window(childId);
        driver.findElement(By.id("add-to-cart-button")).click();



        WebDriverWait w=new WebDriverWait(driver, Duration.ofSeconds(50));
        w.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"attach-sidesheet-view-cart-button\"]/span/input"))).click();
        WebElement ProductText=driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div[5]/div/div[2]/div[1]/div/form/div[2]/div[3]/div[4]/div/div[3]/ul/li[1]/span/a/span[1]/span/span[2]"));
        WebElement ProductPrice=driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div[5]/div/div[2]/div[1]/div/form/div[2]/div[3]/div[4]/div/div[3]/ul/div/div/div/p/span"));
        String ExpectedPrice = "745.00";
        String ActualPrice=ProductPrice.getText().trim();

        if(ActualPrice.equalsIgnoreCase(ExpectedPrice))
        {
            System.out.println("Correct Price is displayed in Shopping cart");
        }
        else {
            System.out.println("Correct Price is not displayed");
        }
        //driver.findElement(By.xpath("//*[@id=\"sc-buy-box-ptc-button\"]/span/input")).click();
        //w.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"orderSummaryPrimaryActionBtn\"]/span/input"))).click();
        //Thread.sleep(5000);
        //WebElement CouponCode=driver.findElement(By.id("pp-XXBb8Z-97"));
        //System.out.println("Coupon coode is" +CouponCode);
        //Thread.sleep(3000);
        //driver.navigate().back();

    }

    @And("User increases the quantity of products in cart")

        public void User_increases_quantityInCart() throws InterruptedException {
        WebElement Quantity=driver.findElement(By.xpath("//span[contains(@class,'a-dropdown-prompt')]"));
        Quantity.click();
        driver.findElement(By.xpath("//*[@id=\"quantity_4\"]")).click();
        System.out.println("Increase the quantity of products");
        Thread.sleep(3000);
    }
    @And("User deletes the item from cart")
    public void User_deletes_product() throws InterruptedException {   //driver.findElement(By.linkText("Delete")).click();
        WebElement deleteProduct=driver.findElement((By.cssSelector("input[data-action='delete']")));
        deleteProduct.click();
        Thread.sleep(3000);
        System.out.println("Item removed from shopping cart");
        driver.quit();
    }

}
