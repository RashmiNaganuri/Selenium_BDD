package org.example.stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SearchSort {

    WebDriver driver = new EdgeDriver();

    @Given("User logs into the amazon website")
    public void User_logs_website() {
        System.setProperty("Webdriver.edge.driver", "C:\\Selenium Jars and drivers\\drivers\\edgedriver_win64.exe");
        driver.get("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2F%3Fref_%3Dnav_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0");
        driver.findElement(By.xpath("//*[@id=\"ap_email\"]")).sendKeys("rashmi.naganuri234@gmail.com");
        driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"ap_password\"]")).sendKeys("Rash8050656505");
        driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
        driver.manage().window().maximize();
        System.out.println("User is able to log in to the website");
    }

    @And("User searches the relevant product by applying multiple filters")
    public void User_searches_product() throws InterruptedException {
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys("pens");
        driver.findElement(By.xpath("//*[@id=\"nav-search-submit-button\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"p_89/Cello\"]/span/a/div/label/i")).click();
        driver.findElement(By.xpath("//*[@id=\"low-price\"]")).sendKeys("50");
        driver.findElement(By.xpath("//*[@id=\"high-price\"]")).sendKeys("70");
        driver.findElement(By.xpath("//span[contains(@class,'a-button a-spacing-top-mini a-button-base s-small-margin-left')]")).click();
        Thread.sleep(3000);
        List<WebElement> products = driver.findElements(By.xpath("//span[contains(@class,'a-size-base-plus a-color-base a-text-normal')]"));

        for (WebElement prodlist : products) {

            String Actualvalue = prodlist.getText();
            System.out.println("User is able to view all the relevant products: " + Actualvalue);
        }
    }

        @Then("User performs the sorting functionality")
        public void User_performs_sorting()
        {
            driver.findElement(By.xpath("//*[@id=\"a-autoid-3-announce\"]/span[1]")).click();
            driver.findElement(By.xpath("//*[@id=\"s-result-sort-select_1\"]")).click();
            List<WebElement> sortedElements = driver.findElements(By.xpath("//span[contains(@class,'a-size-base-plus a-color-base a-text-normal')]"));
            //store the text value of sorted elements in a list

            List<String> actualSortedList = new ArrayList<>();
            for (WebElement element : sortedElements) {
                actualSortedList.add(element.getText());
            }
            //create a sorted copy of the actual list
            List<String> expectedSortedList = new ArrayList<>(actualSortedList);
            Collections.sort(expectedSortedList);

            if (expectedSortedList.equals(actualSortedList)) {
                System.out.println("Sorting is successful");
            } else {
                System.out.println("Sorting failed");
            }
            driver.close();
        }

    }


